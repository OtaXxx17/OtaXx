module.exports = {
  OWNER_URL: "https://t.me/", // Link Telegram kamu
  owner: "",     // ID Telegram kamu (angka)
  domain: "",    // Domain/link bot (opsional)
  plta: "",      // Nomor PLT A (opsional)
  pltc: "",      // Nomor PLT C (opsional)
  qris: "https://img2.pixhost.to/images/7147/714632804_otax.jpg",      // Link/gambar QRIS (opsional)
  dana: "Nomor kamu",      // Nomor Dana (opsional)
  gopay: "nomor kamu",     // Nomor GoPay (opsional)
  ovo: "nomor kamu",       // Nomor OVO (opsional)
  shopeepay: "nomor kamu",
};
// silahkan diisi payment agar bisa digunakan di via whatsapp OTAX